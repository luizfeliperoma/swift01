//
//  Aula01App.swift
//  Aula01
//
//  Created by Turma02 on 02/07/25.
//

import SwiftUI

@main
struct Aula01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
